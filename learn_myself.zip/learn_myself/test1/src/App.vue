<script setup>
import {computed, ref} from "vue";
import BlogPost from "@/components/BlogPost.vue";

  // 基础1(数据、方法函数、for_if语句)
  const blogs = ref([   // ref:响应式
    {
      id: 1,
      title: "Vue3 基础",
      content: "Vue3 在 Vue2 的基础上发生了重大变化",
      link: "/vue-3-tutorial",
    },
    {
      id: 2,
      title: "Vue3 基础",
      content: "Vue3 在 Vue2 的基础上发生了重大变化2",
      link: "/vue-3-tutorial",
    },
    {
      id: 3,
      title: "Vue3 基础",
      content: "Vue3 在 Vue2 的基础上发生了重大变化3",
      link: "/vue-3-tutorial",
    }
  ]);
  // computed: 计算属性
  const total = computed(() => blogs.value.length);
  const showTotal = ref(true);
  function toggleTotal() {
    showTotal.value = !showTotal.value;
  }

  // 基础2(表单提交)
  const initialBlogForm = {
    title: "",
    content: "",
    link: "",
  };
  const blogForm = ref({...initialBlogForm})
  function addPost() {
    blogs.value.push({
      id: blogs.value.length + 1,
      ... blogForm.value,
    });
    blogForm.value = {...initialBlogForm};
    console.log("添加成功")
  }

  // 基础3(如果把所有代码写在同一个组件中不妥，所以出现了组件)

  // 基础4(生命周期)

  // 基础5(子组件触发事件来让父组件进行处理)
  function handleTitleClick(title) {
    console.log(title)
  }
</script>


<template>
<!--  基础1  -->
<!--  <div v-for="blog in blogs" :key="blog.id">-->
<!--    <h1>-->
<!--      <a :href="blog.link">{{ blog.title }}</a>-->
<!--    </h1>-->
<!--    <article>-->
<!--      <div>-->
<!--        {{ blog.content.slice(0, 100) }}-->
<!--      </div>-->
<!--      <footer v-if="blog.content.length > 10">-->
<!--        <button>阅读原文</button>-->
<!--      </footer>-->
<!--    </article>-->
<!--  </div>-->
<!--  基础3  -->
<!--  <BlogPost v-for="blog in blogs" :key="blog.id"-->
<!--  :title="blog.title"-->
<!--  :content="blog.content"-->
<!--  :link="blog.link"-->
<!--  >-->
<!--  </BlogPost>-->
  <BlogPost v-for="blog in blogs" :key="blog.id"
            v-bind="blog"
            @titleClick="handleTitleClick"
  >
    <button>分享到微信</button>
  </BlogPost>
  <h3 v-if="showTotal">总共：{{ total }}篇</h3>
  <button @click="toggleTotal">{{ showTotal ? "隐藏" : "显示" }}</button>
<!--  基础2  -->
  <form @submit.prevent="addPost"> <!-- 事件修饰符，组织表单提交行为 -->
    <label for="blogTitle">博客标题</label>
    <input type="text" id="blogTitle" v-model="blogForm.title"/>
    <label for="contest">内容</label>
    <textarea id="contest" cols="30" rows="10" v-model="blogForm.content"></textarea>
    <label for="link">链接</label>
    <input type="text" id="link" v-model="blogForm.link"/>
    <button type="submit">提交</button>
  </form>

</template>


<style scoped>
  form {
    display: grid;
    margin-top: 2em;
  }

</style>
