
<!--  基础3  -->
<template>
  <div>
    <h1>
      <a :href="link" @click.prevent="$emit('titleClick', title)">{{ title }}</a>
    </h1>
    <article>
      <div>
        {{ content.slice(0, 100) }}
      </div>
      <p>阅读量：{{ viewCount }}</p>
      <footer v-if="content.length > 10">
        <button>阅读原文</button>
      </footer>
    </article>
  </div>

<!-- 占位传递代码  -->
  <slot></slot>

</template>

<script setup>

// 接收传递的值
import {onMounted, ref} from "vue"

defineProps(["title", "content", "link"]);

// 基础4(生命周期)
// 只有在script中访问value属性才需要.value，在template中并不需要
const viewCount = ref(0);
onMounted(() => {
  setTimeout(() => {
    viewCount.value = 1000000;
  }, 3000)
})

// 5
defineEmits(["titleClick"])

</script>

<style scoped>

</style>