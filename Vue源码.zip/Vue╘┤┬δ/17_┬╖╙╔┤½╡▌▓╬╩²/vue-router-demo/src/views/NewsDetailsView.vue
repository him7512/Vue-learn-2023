<template>
    <h3>新闻详情</h3>
    <p>{{ $route.params.name }}</p>
</template>