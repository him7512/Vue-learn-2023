<template>
  <div class="home">
    <h3>首页</h3>
  </div>
</template>

<script>

export default {
  name: 'HomeView',
  components: {
  }
}
</script>
